# Building the APK from your phone, using GitHub

You don't need Android Studio or a computer for this — GitHub's servers do the
actual build. Your phone just needs to get two files into a GitHub repo.

## 1. Create a new repository
On github.com (in your phone's browser, or the GitHub app) → **New repository**
→ any name (e.g. `cinefree-build`) → **Create repository**. Public or private
both work.

## 2. Upload the zip as `source.zip`
On the empty repo's page → **Add file** → **Upload files** → pick
`CineFree-phase1-scaffold.zip` from your downloads. Before committing, rename
it to exactly:
```
source.zip
```
Commit directly to the `main` branch.

## 3. Add the workflow file
Back on the repo → **Add file** → **Create new file**. For the file name, type:
```
.github/workflows/build-apk.yml
```
(the leading `.github/...` in the name box automatically creates the folders).
Paste in the contents of `build-apk.yml` (included in the zip, or copy it from
this conversation), then commit directly to `main`.

Committing this second file is what starts the first build automatically,
since `source.zip` is already in the repo from step 2.

## 4. Watch it build
Open the **Actions** tab at the top of the repo. You'll see a run in progress
("Build APK"). It typically takes 3-6 minutes. A green check means it
succeeded; a red X means something failed — tap into the run and the failing
step to see why (most likely cause: a typo when pasting the workflow file).

## 5. Download the APK
On the finished run's page, scroll down to **Artifacts** and tap
**CineFree-debug-apk**. This downloads a zip containing `app-debug.apk`.

## 6. Install it on your phone
Extract `app-debug.apk` from that zip (your phone's Files app can usually do
this — look for "Extract" or "Unzip"), then tap the `.apk` file to install it.
Android will likely ask you to allow installs from that source
(**Settings → Apps → [Files/Browser] → Install unknown apps**) the first time.

This is a **debug build** — self-signed automatically, fine for installing on
your own device, not meant for the Play Store. It's also just the Phase 1
scaffold: Home screen, project creation, media import, and the timeline UI
work; the live preview and the actual export-to-MP4 pipeline are the two
pieces still to be built (see the README's "Next implementation steps").

## To rebuild after future changes
Any time you update `source.zip` in the repo (Add file → Upload files →
overwrite it) and commit, the workflow re-runs automatically — repeat steps
4-5 to get the new APK.
