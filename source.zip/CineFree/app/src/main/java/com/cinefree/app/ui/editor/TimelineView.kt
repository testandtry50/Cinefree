package com.cinefree.app.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.cinefree.app.model.Clip
import com.cinefree.app.model.Track
import com.cinefree.app.model.TrackType
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * A scrollable, zoomable-in-a-later-pass multi-track timeline (§13 of the
 * product spec). This first pass renders proportionally-widthed clip
 * blocks; pinch-to-zoom, thumbnail strips, and waveform rendering are the
 * next layer to add once the GL frame-extraction pipeline exists.
 */
@Composable
fun TimelineView(
    tracks: List<Track>,
    pixelsPerSecond: Float = 60f,
    onClipTap: (trackId: String, clip: Clip) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .horizontalScroll(scrollState)
            .padding(vertical = 8.dp)
    ) {
        if (tracks.isEmpty()) {
            Text(
                "Tap \"Add media\" to start your timeline",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(16.dp)
            )
        }
        tracks.forEach { track ->
            TrackRow(track = track, pixelsPerSecond = pixelsPerSecond, onClipTap = onClipTap)
        }
    }
}

@Composable
private fun TrackRow(
    track: Track,
    pixelsPerSecond: Float,
    onClipTap: (trackId: String, clip: Clip) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        track.clips.forEach { clip ->
            val durationSec = TimeUnit.MICROSECONDS.toMillis(clip.endInTrackUs - clip.startInTrackUs) / 1000f
            val widthDp = max(24f, durationSec * pixelsPerSecond)

            Box(
                modifier = Modifier
                    .padding(end = 2.dp)
                    .width(widthDp.dp)
                    .height(trackHeight(track.type))
                    .clip(RoundedCornerShape(6.dp))
                    .background(trackColor(track.type))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = trackIcon(track.type),
                    contentDescription = track.type.name,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

private fun trackHeight(type: TrackType) = when (type) {
    TrackType.VIDEO -> 56.dp
    TrackType.AUDIO -> 40.dp
    else -> 32.dp
}

private fun trackColor(type: TrackType) = when (type) {
    TrackType.VIDEO -> Color(0xFF3B5F8A)
    TrackType.AUDIO -> Color(0xFF3B8A5F)
    TrackType.TEXT -> Color(0xFF8A5F3B)
    TrackType.STICKER -> Color(0xFF8A3B7A)
    TrackType.EFFECT -> Color(0xFF7A3B8A)
}

private fun trackIcon(type: TrackType) = when (type) {
    TrackType.AUDIO -> Icons.Default.MusicNote
    TrackType.TEXT -> Icons.Default.TextFields
    else -> Icons.Default.Movie
}
