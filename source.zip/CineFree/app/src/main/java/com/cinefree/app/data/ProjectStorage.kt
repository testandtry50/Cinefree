package com.cinefree.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Local-only storage for project metadata + autosave payload.
 *
 * Nothing in this file ever touches the network. `payloadJson` holds the
 * serialized Project tree (see model/Project.kt); keeping the full editable
 * state here — not just a thumbnail — is what makes crash recovery and
 * autosave possible (§22 of the product spec).
 */
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val thumbnailPath: String?,
    val durationUs: Long,
    val createdAtEpochMs: Long,
    val modifiedAtEpochMs: Long,
    /** Full serialized Project tree — the source of truth for autosave/recovery. */
    val payloadJson: String,
    /** True if the app did not shut down cleanly while this was the open project. */
    val hasUnrecoveredCrash: Boolean = false
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY modifiedAtEpochMs DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getById(id: String): ProjectEntity?

    @Query("SELECT * FROM projects WHERE hasUnrecoveredCrash = 1 LIMIT 1")
    suspend fun findUnrecoveredCrash(): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE projects SET hasUnrecoveredCrash = :value WHERE id = :id")
    suspend fun setCrashFlag(id: String, value: Boolean)
}

@Database(entities = [ProjectEntity::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "cinefree.db"
                ).build().also { instance = it }
            }
    }
}
