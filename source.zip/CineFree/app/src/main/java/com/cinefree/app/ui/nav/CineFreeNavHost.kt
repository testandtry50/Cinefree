package com.cinefree.app.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cinefree.app.data.ProjectRepository
import com.cinefree.app.ui.editor.EditorScreen
import com.cinefree.app.ui.home.HomeScreen

private object Routes {
    const val HOME = "home"
    const val EDITOR = "editor/{projectId}"
    fun editor(projectId: String) = "editor/$projectId"
}

/**
 * The entire app is two screens plus tool bottom-sheets, per the mobile UI
 * spec: Home (Projects) -> Editor. Export happens from within the Editor
 * screen rather than as a separate destination, so the user is never more
 * than one tap from the timeline.
 */
@Composable
fun CineFreeNavHost(repository: ProjectRepository) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                repository = repository,
                onOpenProject = { projectId -> navController.navigate(Routes.editor(projectId)) }
            )
        }
        composable(
            route = Routes.EDITOR,
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments!!.getString("projectId")!!
            EditorScreen(
                projectId = projectId,
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
