package com.cinefree.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cinefree.app.data.ProjectRepository
import com.cinefree.app.data.ProjectSummary
import com.cinefree.app.model.AspectRatio
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: ProjectRepository,
    onOpenProject: (String) -> Unit
) {
    val viewModel: HomeViewModel = viewModel(factory = homeViewModelFactory(repository))
    val projects by viewModel.projects.collectAsState()
    var showNewProjectDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("CineFree") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showNewProjectDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "New project")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {

            viewModel.recoverableProjectId?.let { crashedId ->
                RecoveryBanner(
                    onRecover = { onOpenProject(crashedId) },
                    onDismiss = { viewModel.deleteProject(crashedId) }
                )
            }

            if (projects.isEmpty()) {
                EmptyState(modifier = Modifier.weight(1f))
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(projects, key = { it.id }) { project ->
                        ProjectCard(project = project, onClick = { onOpenProject(project.id) })
                    }
                }
            }
        }
    }

    if (showNewProjectDialog) {
        NewProjectDialog(
            onDismiss = { showNewProjectDialog = false },
            onCreate = { name, ratio ->
                showNewProjectDialog = false
                viewModel.createProject(name, ratio) { newId -> onOpenProject(newId) }
            }
        )
    }
}

@Composable
private fun RecoveryBanner(onRecover: () -> Unit, onDismiss: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("CineFree closed unexpectedly", style = MaterialTheme.typography.titleSmall)
                Text("A project may have unsaved changes.", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onDismiss) { Text("Discard") }
            Button(onClick = onRecover) { Text("Recover") }
        }
    }
}

@Composable
private fun EmptyState(modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(12.dp))
            Text("No projects yet")
            Text("Tap + to start your first edit — free, offline, no account.",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ProjectCard(project: ProjectSummary, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(9f / 16f)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                // Real thumbnail rendering (extracted from the first frame via
                // MediaMetadataRetriever) is a Phase 1 follow-up; this is the
                // placeholder slot it will render into.
                Icon(
                    Icons.Default.Movie,
                    contentDescription = null,
                    modifier = Modifier.align(Alignment.Center).size(32.dp)
                )
                Text(
                    text = formatDuration(project.durationUs),
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                )
            }
            Text(
                text = project.name,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(8.dp)
            )
        }
    }
}

@Composable
private fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (String, AspectRatio) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var ratio by remember { mutableStateOf(AspectRatio.RATIO_9_16) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New project") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Text("Aspect ratio", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.fillMaxWidth()) {
                    listOf(AspectRatio.RATIO_9_16, AspectRatio.RATIO_1_1, AspectRatio.RATIO_16_9).forEach { option ->
                        FilterChip(
                            selected = ratio == option,
                            onClick = { ratio = option },
                            label = { Text(option.label) },
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onCreate(name, ratio) }) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun formatDuration(us: Long): String {
    val totalSeconds = TimeUnit.MICROSECONDS.toSeconds(us)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
