package com.cinefree.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cinefree.app.data.ProjectRepository
import com.cinefree.app.data.ProjectSummary
import com.cinefree.app.model.AspectRatio
import com.cinefree.app.model.Project
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val repository: ProjectRepository) : ViewModel() {

    val projects: StateFlow<List<ProjectSummary>> = repository.observeProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    var recoverableProjectId: String? = null
        private set

    init {
        viewModelScope.launch {
            recoverableProjectId = repository.findCrashedProject()?.id
        }
    }

    /** Creates a new project with the chosen aspect ratio and returns its id for navigation. */
    fun createProject(name: String, aspectRatio: AspectRatio, onCreated: (String) -> Unit) {
        viewModelScope.launch {
            val (width, height) = when (aspectRatio) {
                AspectRatio.RATIO_9_16 -> 1080 to 1920
                AspectRatio.RATIO_1_1 -> 1080 to 1080
                AspectRatio.RATIO_16_9 -> 1920 to 1080
                AspectRatio.CUSTOM -> 1080 to 1920
            }
            val project = Project(
                name = name.ifBlank { "Untitled project" },
                aspectRatio = aspectRatio,
                resolutionWidth = width,
                resolutionHeight = height
            )
            repository.save(project, markPossiblyDirty = false)
            onCreated(project.id)
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch { repository.delete(id) }
    }
}
