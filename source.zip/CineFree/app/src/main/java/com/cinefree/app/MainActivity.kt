package com.cinefree.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.cinefree.app.ui.nav.CineFreeNavHost
import com.cinefree.app.ui.theme.CineFreeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = (application as CineFreeApp).projectRepository

        setContent {
            CineFreeTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CineFreeNavHost(repository = repository)
                }
            }
        }
    }
}
