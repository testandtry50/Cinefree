package com.cinefree.app.data

import android.content.Context
import com.cinefree.app.model.Project
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Single entry point for reading/writing projects. Everything here is
 * local-only (Room/SQLite on-device) — there is no remote data source in
 * this app, by design (§19, Offline architecture).
 *
 * Autosave model (§22, Data/project architecture):
 *  - `save()` is called after every discrete edit action from the editor
 *    ViewModel, off the main thread, and marks the project as having a
 *    "possibly unclean" state until `markClean()` runs on a graceful pause.
 *  - On next app start, `findCrashedProject()` lets the Home screen offer
 *    a "Recover last session" prompt instead of silently losing work.
 */
class ProjectRepository(context: Context) {

    private val dao = AppDatabase.get(context).projectDao()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun observeProjects(): Flow<List<ProjectSummary>> =
        dao.observeAll().map { list -> list.map { it.toSummary() } }

    suspend fun load(projectId: String): Project? {
        val entity = dao.getById(projectId) ?: return null
        return json.decodeFromString(Project.serializer(), entity.payloadJson)
    }

    /** Persists the full project tree. Called after every discrete edit for autosave. */
    suspend fun save(project: Project, thumbnailPath: String? = null, markPossiblyDirty: Boolean = true) {
        val durationUs = project.tracks
            .flatMap { it.clips }
            .maxOfOrNull { it.endInTrackUs } ?: 0L

        dao.upsert(
            ProjectEntity(
                id = project.id,
                name = project.name,
                thumbnailPath = thumbnailPath,
                durationUs = durationUs,
                createdAtEpochMs = project.createdAtEpochMs,
                modifiedAtEpochMs = System.currentTimeMillis(),
                payloadJson = json.encodeToString(project),
                hasUnrecoveredCrash = markPossiblyDirty
            )
        )
    }

    /** Call when the editor is exited normally (not via a crash). */
    suspend fun markClean(projectId: String) = dao.setCrashFlag(projectId, value = false)

    suspend fun findCrashedProject(): ProjectSummary? =
        dao.findUnrecoveredCrash()?.toSummary()

    suspend fun delete(projectId: String) = dao.delete(projectId)

    private fun ProjectEntity.toSummary() = ProjectSummary(
        id = id,
        name = name,
        thumbnailPath = thumbnailPath,
        durationUs = durationUs,
        modifiedAtEpochMs = modifiedAtEpochMs
    )
}

/** Lightweight row for the Home screen grid — avoids deserializing the full timeline just to list projects. */
data class ProjectSummary(
    val id: String,
    val name: String,
    val thumbnailPath: String?,
    val durationUs: Long,
    val modifiedAtEpochMs: Long
)
