package com.cinefree.app

import android.app.Application
import com.cinefree.app.data.ProjectRepository

class CineFreeApp : Application() {
    // Single shared repository instance; no dependency-injection framework needed at this scale.
    lateinit var projectRepository: ProjectRepository
        private set

    override fun onCreate() {
        super.onCreate()
        projectRepository = ProjectRepository(this)
    }
}
