package com.cinefree.app.ui.editor

import android.content.pm.ActivityInfo
import android.media.MediaMetadataRetriever
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cinefree.app.data.ProjectRepository
import com.cinefree.app.ui.LockScreenOrientation

/**
 * Screen palette. The dial (center Media button + satellites) and the
 * floating top-right icons keep the same dark-circle/white-icon treatment
 * in both modes — that's true in the "Dark Minimal" and "Light Mode"
 * mockups alike, since those buttons float over arbitrary video content,
 * not over app chrome. Only the page background, rail icon tint, and
 * dividers switch with the system setting.
 */
private data class EditorPalette(
    val background: Color,
    val railIcon: Color,
    val ringOutline: Color,
    val divider: Color
)

@Composable
private fun editorPalette(): EditorPalette {
    return if (isSystemInDarkTheme()) {
        EditorPalette(
            background = Color(0xFF0B0B0F),
            railIcon = Color(0xFFE7E7EC),
            ringOutline = Color(0xFF2A2A33),
            divider = Color(0xFF232329)
        )
    } else {
        EditorPalette(
            background = Color(0xFFF5F5F7),
            railIcon = Color(0xFF2B2B33),
            ringOutline = Color(0xFFDCDCE2),
            divider = Color(0xFFE3E3E8)
        )
    }
}

private val AccentStart = Color(0xFFEC4899)
private val AccentEnd = Color(0xFF8B5CF6)

private data class EditorTool(val label: String, val icon: ImageVector)

// Center = the primary action (mockup's AI slot, repurposed to Media per
// the no-AI product requirement). The four satellites are the rest of the
// existing toolset, arranged around it exactly like the reference mockup.
private val centerTool = EditorTool("Media", Icons.Default.PermMedia)
private val satelliteTools = listOf(
    EditorTool("Trim", Icons.Default.ContentCut),      // top
    EditorTool("Audio", Icons.Default.MusicNote),       // right
    EditorTool("Effects", Icons.Default.AutoAwesomeMotion), // bottom
    EditorTool("Text", Icons.Default.TextFields),        // left
)

private enum class EditorOrientation(val label: String, val icon: ImageVector, val activityInfoValue: Int) {
    LANDSCAPE("Landscape", Icons.Default.StayCurrentLandscape, ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE),
    PORTRAIT("Portrait", Icons.Default.StayCurrentPortrait, ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT),
    AUTO("Auto-rotate", Icons.Default.ScreenRotation, ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
}

@Composable
fun EditorScreen(
    projectId: String,
    repository: ProjectRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = editorPalette()
    val viewModel: EditorViewModel = viewModel(factory = editorViewModelFactory(projectId, repository))
    val uiState by viewModel.uiState.collectAsState()

    var orientationChoice by remember { mutableStateOf(EditorOrientation.LANDSCAPE) }
    LockScreenOrientation(orientation = orientationChoice.activityInfoValue)

    var showExportSheet by remember { mutableStateOf(false) }
    var activeTool by remember { mutableStateOf<String?>(null) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) viewModel.markSessionClean()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val goBack = { viewModel.markSessionClean(); onBack() }
    BackHandler { goBack() }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        context.contentResolver.takePersistableUriPermission(
            uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        val retriever = MediaMetadataRetriever()
        val durationUs: Long = try {
            retriever.setDataSource(context, uri)
            val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            ms * 1000
        } finally {
            retriever.release()
        }
        viewModel.addVideoClip(uri.toString(), durationUs)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
    ) {
        when (val state = uiState) {
            is EditorUiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is EditorUiState.Ready -> {
                Column(modifier = Modifier.fillMaxSize()) {

                    Row(modifier = Modifier.fillMaxWidth().weight(1f)) {

                        SideIconRail(
                            palette = palette,
                            onBack = goBack,
                            onToolStub = { activeTool = it }
                        )

                        // Preview canvas. Real playback here is the GL compositor described in
                        // §16/§20 of the spec, fed by MediaCodec-decoded frames — the same
                        // pipeline export will reuse, so preview and export can never diverge.
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.inverseSurface,
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .aspectRatio(state.project.resolutionWidth.toFloat() / state.project.resolutionHeight)
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                    Text(
                                        "Preview\n(GL compositor not yet wired up)",
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.inverseOnSurface,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        ToolDial(
                            palette = palette,
                            onCenterTap = { pickMedia.launch("video/*") },
                            onSatelliteTap = { tool ->
                                if (tool == "Trim" || tool == "Audio" || tool == "Effects" || tool == "Text") {
                                    activeTool = tool
                                }
                            }
                        )
                    }

                    HorizontalDivider(color = palette.divider)

                    TimelineView(
                        tracks = state.project.tracks,
                        onClipTap = { _, _ -> /* selection handling: next build pass */ },
                        modifier = Modifier.fillMaxWidth().height(140.dp)
                    )
                }
            }
        }

        // Floating top-right icons only — back now lives in the rail, matching the mockup.
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OrientationLockButton(current = orientationChoice, onSelect = { orientationChoice = it })
            FloatingIconButton(
                icon = Icons.Default.FileUpload,
                contentDescription = "Export",
                onClick = { showExportSheet = true }
            )
        }
    }

    if (showExportSheet) {
        ExportSheet(onDismiss = { showExportSheet = false })
    }
    activeTool?.let { tool ->
        ToolStubSheet(toolName = tool, onDismiss = { activeTool = null })
    }
}

/** Left-edge icon rail: back, undo/redo, crop, settings, then a small divider and mixer/fit icons. */
@Composable
private fun SideIconRail(palette: EditorPalette, onBack: () -> Unit, onToolStub: (String) -> Unit) {
    Column(
        modifier = Modifier
            .width(56.dp)
            .fillMaxHeight()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        RailIcon(Icons.AutoMirrored.Filled.ArrowBack, "Back", palette.railIcon, onBack)
        Spacer(Modifier.height(4.dp))
        RailIcon(Icons.AutoMirrored.Filled.Undo, "Undo", palette.railIcon) { onToolStub("Undo") }
        RailIcon(Icons.AutoMirrored.Filled.Redo, "Redo", palette.railIcon) { onToolStub("Redo") }
        RailIcon(Icons.Default.Crop, "Crop / aspect ratio", palette.railIcon) { onToolStub("Crop") }
        RailIcon(Icons.Default.Settings, "Project settings", palette.railIcon) { onToolStub("Settings") }
        HorizontalDivider(modifier = Modifier.width(24.dp), color = palette.divider)
        RailIcon(Icons.Default.Tune, "Audio mixer", palette.railIcon) { onToolStub("Audio mixer") }
        RailIcon(Icons.Default.AspectRatio, "Fit to screen", palette.railIcon) { onToolStub("Fit to screen") }
    }
}

@Composable
private fun RailIcon(icon: ImageVector, contentDescription: String, tint: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = tint)
    }
}

/** The right-side circular dial: a ring outline, four satellite tools, and an accent-gradient center button. */
@Composable
private fun ToolDial(
    palette: EditorPalette,
    onCenterTap: () -> Unit,
    onSatelliteTap: (String) -> Unit
) {
    val ringDiameter = 150.dp
    val satelliteSize = 44.dp
    val centerSize = 56.dp

    Box(
        modifier = Modifier.width(150.dp).fillMaxHeight(),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(ringDiameter)
                .clip(CircleShape)
                .border(1.dp, palette.ringOutline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // top
            DialSatellite(satelliteTools[0], satelliteSize, onSatelliteTap, Modifier.align(Alignment.TopCenter))
            // right
            DialSatellite(satelliteTools[1], satelliteSize, onSatelliteTap, Modifier.align(Alignment.CenterEnd))
            // bottom
            DialSatellite(satelliteTools[2], satelliteSize, onSatelliteTap, Modifier.align(Alignment.BottomCenter))
            // left
            DialSatellite(satelliteTools[3], satelliteSize, onSatelliteTap, Modifier.align(Alignment.CenterStart))

            // Center accent button — this is the mockup's "AI" slot, repurposed to Media.
            Box(
                modifier = Modifier
                    .size(centerSize)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(AccentStart, AccentEnd)))
                    .clickable(onClick = onCenterTap),
                contentAlignment = Alignment.Center
            ) {
                Icon(centerTool.icon, contentDescription = centerTool.label, tint = Color.White)
            }
        }
        Text(
            centerTool.label,
            style = MaterialTheme.typography.labelSmall,
            color = palette.railIcon,
            modifier = Modifier.align(Alignment.Center).offset(y = 40.dp)
        )
    }
}

@Composable
private fun DialSatellite(
    tool: EditorTool,
    size: androidx.compose.ui.unit.Dp,
    onTap: (String) -> Unit,
    modifier: Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.55f))
                .clickable { onTap(tool.label) },
            contentAlignment = Alignment.Center
        ) {
            Icon(tool.icon, contentDescription = tool.label, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Text(tool.label, style = MaterialTheme.typography.labelSmall, color = Color.White)
    }
}

@Composable
private fun FloatingIconButton(icon: ImageVector, contentDescription: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = Color.White)
    }
}

@Composable
private fun OrientationLockButton(current: EditorOrientation, onSelect: (EditorOrientation) -> Unit) {
    var menuOpen by remember { mutableStateOf(false) }
    Box {
        FloatingIconButton(
            icon = current.icon,
            contentDescription = "Screen orientation: ${current.label}",
            onClick = { menuOpen = true }
        )
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            EditorOrientation.entries.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.label) },
                    leadingIcon = { Icon(option.icon, contentDescription = null) },
                    trailingIcon = {
                        if (option == current) Icon(Icons.Default.Check, contentDescription = "Selected")
                    },
                    onClick = {
                        onSelect(option)
                        menuOpen = false
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ToolStubSheet(toolName: String, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(toolName, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "This tool's controls are the next build pass — the data model " +
                    "(Clip.transform, Clip.effects, Clip.keyframes, TextContent) " +
                    "already has the fields this panel will edit.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExportSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text("Export", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "The MediaCodec hardware-encode pipeline (§18 of the spec) isn't " +
                    "wired up in this scaffold yet. When implemented, this sheet will:\n" +
                    "\n" +
                    "1. Show resolution / frame-rate / format options.\n" +
                    "2. Compute a real free-space check via StatFs and show an " +
                    "estimated output size before the user taps Export.\n" +
                    "3. Stream-encode directly to the final file via MediaMuxer + " +
                    "MediaCodec (no full-resolution temp copy).\n" +
                    "4. Run as a WorkManager job with a progress notification, so " +
                    "it survives the user leaving the app.\n" +
                    "\n" +
                    "No watermark logic exists anywhere in this pipeline, by design.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
