package com.cinefree.app.ui.editor

import android.content.pm.ActivityInfo
import android.media.MediaMetadataRetriever
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cinefree.app.data.ProjectRepository
import com.cinefree.app.ui.LockScreenOrientation

private data class EditorPalette(
    val background: Color,
    val railIcon: Color,
    val ringOutline: Color,
    val divider: Color,
    val badgeBackground: Color,
    val badgeText: Color
)

@Composable
private fun editorPalette(): EditorPalette {
    return if (isSystemInDarkTheme()) {
        EditorPalette(
            background = Color(0xFF0B0B0F),
            railIcon = Color(0xFFE7E7EC),
            ringOutline = Color(0xFF2A2A33),
            divider = Color(0xFF232329),
            badgeBackground = Color(0xFF1C1C22),
            badgeText = Color(0xFFECECEC)
        )
    } else {
        EditorPalette(
            background = Color(0xFFF5F5F7),
            railIcon = Color(0xFF2B2B33),
            ringOutline = Color(0xFFDCDCE2),
            divider = Color(0xFFE3E3E8),
            badgeBackground = Color(0xFFE7E7EC),
            badgeText = Color(0xFF1C1C22)
        )
    }
}

private val AccentStart = Color(0xFFEC4899)
private val AccentEnd = Color(0xFF8B5CF6)

/** The four wheel positions — fixed in place; the center hub shows whichever one is active. */
private enum class WheelItem(val label: String, val icon: ImageVector) {
    MEDIA("Media", Icons.Default.PermMedia),
    LAYER("Layer", Icons.Default.Layers),
    AUDIO("Audio", Icons.Default.MusicNote),
    REC("REC", Icons.Default.Mic)
}

private data class SubOption(val label: String, val icon: ImageVector)

private val layerSubOptions = listOf(
    SubOption("Media", Icons.Default.Image),
    SubOption("Effect", Icons.Default.AutoAwesome),
    SubOption("Handwriting", Icons.Default.Draw),
    SubOption("Text", Icons.Default.TextFields),
    SubOption("Shape", Icons.Default.Category),
)
private val audioSubOptions = listOf(
    SubOption("Music", Icons.Default.MusicNote),
    SubOption("Sound effect", Icons.Default.GraphicEq),
    SubOption("Extract audio", Icons.Default.Audiotrack),
)

private enum class EditorOrientation(val label: String, val icon: ImageVector, val activityInfoValue: Int) {
    LANDSCAPE("Landscape", Icons.Default.StayCurrentLandscape, ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE),
    PORTRAIT("Portrait", Icons.Default.StayCurrentPortrait, ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT),
    AUTO("Auto-rotate", Icons.Default.ScreenRotation, ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
}

@Composable
fun EditorScreen(
    projectId: String,
    repository: ProjectRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = editorPalette()
    val viewModel: EditorViewModel = viewModel(factory = editorViewModelFactory(projectId, repository))
    val uiState by viewModel.uiState.collectAsState()

    var orientationChoice by remember { mutableStateOf(EditorOrientation.LANDSCAPE) }
    LockScreenOrientation(orientation = orientationChoice.activityInfoValue)

    var showExportSheet by remember { mutableStateOf(false) }
    var stubSheetLabel by remember { mutableStateOf<String?>(null) }

    // Wheel state: which function is centered, and whether its sub-menu is open.
    var activeWheelItem by remember { mutableStateOf(WheelItem.MEDIA) }
    var showSubmenu by remember { mutableStateOf(false) }
    var spinCount by remember { mutableIntStateOf(0) }
    val spinRotation by animateFloatAsState(
        targetValue = spinCount * 360f,
        animationSpec = tween(450),
        label = "wheel-spin"
    )

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) viewModel.markSessionClean()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val goBack = { viewModel.markSessionClean(); onBack() }
    BackHandler { goBack() }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        context.contentResolver.takePersistableUriPermission(
            uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        val retriever = MediaMetadataRetriever()
        val durationUs: Long = try {
            retriever.setDataSource(context, uri)
            val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            ms * 1000
        } finally {
            retriever.release()
        }
        viewModel.addVideoClip(uri.toString(), durationUs)
    }

    // Selecting a wheel item: spins the hub, makes it the active center, and either
    // opens its sub-menu (Layer, Audio) or performs its direct action (Media, REC).
    fun selectWheelItem(item: WheelItem) {
        if (item != activeWheelItem) spinCount++
        activeWheelItem = item
        when (item) {
            WheelItem.MEDIA -> { showSubmenu = false; pickMedia.launch("video/*") }
            WheelItem.REC -> { showSubmenu = false; stubSheetLabel = "Voice recording" }
            WheelItem.LAYER, WheelItem.AUDIO -> showSubmenu = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
    ) {
        when (val state = uiState) {
            is EditorUiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is EditorUiState.Ready -> {
                Column(modifier = Modifier.fillMaxSize()) {

                    Row(modifier = Modifier.fillMaxWidth().weight(1f)) {

                        SideIconRail(
                            palette = palette,
                            onBack = goBack,
                            onToolStub = { stubSheetLabel = it }
                        )

                        // Preview canvas. Real playback here is the GL compositor described in
                        // §16/§20 of the spec, fed by MediaCodec-decoded frames — the same
                        // pipeline export will reuse, so preview and export can never diverge.
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.inverseSurface,
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .aspectRatio(state.project.resolutionWidth.toFloat() / state.project.resolutionHeight)
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    Text(
                                        "Preview\n(GL compositor not yet wired up)",
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.inverseOnSurface,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.align(Alignment.Center)
                                    )
                                    ResolutionBadge(
                                        heightPx = state.project.resolutionHeight,
                                        modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                                    )
                                }
                            }
                        }

                        ToolDial(
                            palette = palette,
                            activeItem = activeWheelItem,
                            spinRotation = spinRotation,
                            onSelect = ::selectWheelItem,
                            onStoreTap = { stubSheetLabel = "Asset store" },
                            onPlayTap = { stubSheetLabel = "Playback" }
                        )
                    }

                    HorizontalDivider(color = palette.divider)

                    TimelineView(
                        tracks = state.project.tracks,
                        onClipTap = { _, _ -> /* selection handling: next build pass */ },
                        modifier = Modifier.fillMaxWidth().height(140.dp)
                    )
                }

                // Sub-menu flyout, anchored just left of the dial — matches the second mockup.
                AnimatedVisibility(
                    visible = showSubmenu,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 170.dp),
                    enter = fadeIn() + scaleIn(initialScale = 0.85f),
                    exit = fadeOut() + scaleOut(targetScale = 0.85f)
                ) {
                    val options = when (activeWheelItem) {
                        WheelItem.LAYER -> layerSubOptions
                        WheelItem.AUDIO -> audioSubOptions
                        else -> emptyList()
                    }
                    SubmenuCard(palette = palette, options = options) { option ->
                        showSubmenu = false
                        if (option == "Media") pickMedia.launch("video/*") else stubSheetLabel = option
                    }
                }
            }
        }

        // Floating top-right badge stack.
        Column(
            modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FloatingIconButton(Icons.Default.FileUpload, "Export") { showExportSheet = true }
            AspectRatioBadge(
                aspect = (uiState as? EditorUiState.Ready)?.project?.aspectRatio?.label ?: "—",
                palette = palette
            )
            FloatingIconButton(Icons.Default.GpsFixed, "Guides") { stubSheetLabel = "Guides / safe area" }
            OrientationLockButton(current = orientationChoice, onSelect = { orientationChoice = it })
        }
    }

    if (showExportSheet) {
        ExportSheet(onDismiss = { showExportSheet = false })
    }
    stubSheetLabel?.let { label ->
        ToolStubSheet(toolName = label, onDismiss = { stubSheetLabel = null })
    }
}

@Composable
private fun ResolutionBadge(heightPx: Int, modifier: Modifier = Modifier) {
    val label = when {
        heightPx >= 2160 -> "4K"
        heightPx >= 1440 -> "2K"
        heightPx >= 720 -> "HD"
        else -> "SD"
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.6f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AspectRatioBadge(aspect: String, palette: EditorPalette) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(palette.badgeBackground)
            .clickable { }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(aspect, color = palette.badgeText, style = MaterialTheme.typography.labelSmall)
    }
}

/** Left-edge icon rail: back, undo/redo, fit, settings, then a divider, adjust, split, volume. */
@Composable
private fun SideIconRail(palette: EditorPalette, onBack: () -> Unit, onToolStub: (String) -> Unit) {
    Column(
        modifier = Modifier
            .width(56.dp)
            .fillMaxHeight()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        RailIcon(Icons.AutoMirrored.Filled.ArrowBack, "Back", palette.railIcon, onBack)
        Spacer(Modifier.height(4.dp))
        RailIcon(Icons.AutoMirrored.Filled.Undo, "Undo", palette.railIcon) { onToolStub("Undo") }
        RailIcon(Icons.AutoMirrored.Filled.Redo, "Redo", palette.railIcon) { onToolStub("Redo") }
        RailIcon(Icons.Default.AspectRatio, "Fit", palette.railIcon) { onToolStub("Fit") }
        RailIcon(Icons.Default.Settings, "Project settings", palette.railIcon) { onToolStub("Settings") }
        HorizontalDivider(modifier = Modifier.width(24.dp), color = palette.divider)
        RailIcon(Icons.Default.Tune, "Adjust", palette.railIcon) { onToolStub("Adjust") }
        RailIcon(Icons.Default.ContentCut, "Split", palette.railIcon) { onToolStub("Split") }
        RailIcon(Icons.Default.VolumeUp, "Volume", palette.railIcon) { onToolStub("Volume") }
    }
}

@Composable
private fun RailIcon(icon: ImageVector, contentDescription: String, tint: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = tint)
    }
}

/** The right-side wheel: ring outline, 4 fixed satellite positions, and a center hub that shows + animates the active item. */
@Composable
private fun ToolDial(
    palette: EditorPalette,
    activeItem: WheelItem,
    spinRotation: Float,
    onSelect: (WheelItem) -> Unit,
    onStoreTap: () -> Unit,
    onPlayTap: () -> Unit
) {
    val ringDiameter = 150.dp
    val satelliteSize = 44.dp
    val centerSize = 60.dp

    Column(
        modifier = Modifier.width(150.dp).fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(modifier = Modifier.size(ringDiameter), contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(ringDiameter)
                    .clip(CircleShape)
                    .border(1.dp, palette.ringOutline, CircleShape)
            )

            WheelItem.entries.forEach { item ->
                val alignment = when (item) {
                    WheelItem.MEDIA -> Alignment.TopCenter
                    WheelItem.AUDIO -> Alignment.CenterEnd
                    WheelItem.REC -> Alignment.BottomCenter
                    WheelItem.LAYER -> Alignment.CenterStart
                }
                DialSatellite(
                    item = item,
                    isActive = item == activeItem,
                    size = satelliteSize,
                    onTap = { onSelect(item) },
                    modifier = Modifier.align(alignment)
                )
            }

            // Center hub — shows the active item, with a decorative spin whenever selection changes.
            Box(
                modifier = Modifier
                    .size(centerSize)
                    .graphicsLayer { rotationZ = spinRotation }
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(AccentStart, AccentEnd)))
                    .clickable { onSelect(activeItem) },
                contentAlignment = Alignment.Center
            ) {
                Icon(activeItem.icon, contentDescription = activeItem.label, tint = Color.White)
            }
        }
        Text(
            activeItem.label,
            style = MaterialTheme.typography.labelSmall,
            color = palette.railIcon,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BadgedStoreIcon(onClick = onStoreTap)
            FloatingIconButton(Icons.Default.PlayArrow, "Play", onPlayTap)
        }
    }
}

@Composable
private fun DialSatellite(
    item: WheelItem,
    isActive: Boolean,
    size: androidx.compose.ui.unit.Dp,
    onTap: () -> Unit,
    modifier: Modifier
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(if (isActive) AccentStart.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.55f))
                .then(if (isActive) Modifier.border(1.5.dp, AccentStart, CircleShape) else Modifier)
                .clickable(onClick = onTap),
            contentAlignment = Alignment.Center
        ) {
            Icon(item.icon, contentDescription = item.label, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Text(item.label, style = MaterialTheme.typography.labelSmall, color = Color.White)
    }
}

@Composable
private fun SubmenuCard(palette: EditorPalette, options: List<SubOption>, onSelect: (String) -> Unit) {
    Surface(
        color = palette.badgeBackground,
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.width(180.dp).padding(vertical = 8.dp)) {
            options.forEach { option ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(option.label) }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Icon(option.icon, contentDescription = null, tint = palette.badgeText, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(16.dp))
                    Text(option.label, color = palette.badgeText, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
private fun BadgedStoreIcon(onClick: () -> Unit) {
    Box {
        FloatingIconButton(Icons.Default.Storefront, "Asset store", onClick)
        Box(
            modifier = Modifier
                .size(9.dp)
                .align(Alignment.TopEnd)
                .clip(CircleShape)
                .background(Color(0xFFE53935))
        )
    }
}

@Composable
private fun FloatingIconButton(icon: ImageVector, contentDescription: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = Color.White)
    }
}

@Composable
private fun OrientationLockButton(current: EditorOrientation, onSelect: (EditorOrientation) -> Unit) {
    var menuOpen by remember { mutableStateOf(false) }
    Box {
        FloatingIconButton(
            icon = current.icon,
            contentDescription = "Screen orientation: ${current.label}",
            onClick = { menuOpen = true }
        )
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            EditorOrientation.entries.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.label) },
                    leadingIcon = { Icon(option.icon, contentDescription = null) },
                    trailingIcon = {
                        if (option == current) Icon(Icons.Default.Check, contentDescription = "Selected")
                    },
                    onClick = {
                        onSelect(option)
                        menuOpen = false
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ToolStubSheet(toolName: String, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(toolName, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "This tool's controls are the next build pass — the data model " +
                    "(Clip.transform, Clip.effects, Clip.keyframes, TextContent) " +
                    "already has the fields this panel will edit.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExportSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text("Export", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "The MediaCodec hardware-encode pipeline (§18 of the spec) isn't " +
                    "wired up in this scaffold yet. When implemented, this sheet will:\n" +
                    "\n" +
                    "1. Show resolution / frame-rate / format options.\n" +
                    "2. Compute a real free-space check via StatFs and show an " +
                    "estimated output size before the user taps Export.\n" +
                    "3. Stream-encode directly to the final file via MediaMuxer + " +
                    "MediaCodec (no full-resolution temp copy).\n" +
                    "4. Run as a WorkManager job with a progress notification, so " +
                    "it survives the user leaving the app.\n" +
                    "\n" +
                    "No watermark logic exists anywhere in this pipeline, by design.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
