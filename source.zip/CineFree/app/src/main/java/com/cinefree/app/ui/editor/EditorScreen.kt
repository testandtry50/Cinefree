package com.cinefree.app.ui.editor

import android.media.MediaMetadataRetriever
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cinefree.app.data.ProjectRepository
import com.cinefree.app.ui.LockScreenOrientation

private data class EditorTool(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val tools = listOf(
    EditorTool("Add media", Icons.Default.Add),
    EditorTool("Trim", Icons.Default.ContentCut),
    EditorTool("Text", Icons.Default.TextFields),
    EditorTool("Audio", Icons.Default.MusicNote),
    EditorTool("Effects", Icons.Default.AutoAwesomeMotion),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    projectId: String,
    repository: ProjectRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val viewModel: EditorViewModel = viewModel(factory = editorViewModelFactory(projectId, repository))
    val uiState by viewModel.uiState.collectAsState()

    // Mobile-editor convention (KineMaster, CapCut, VN, etc. all do this):
    // the project browser is portrait, but editing force-rotates to
    // landscape and locks there — more horizontal room for the preview and
    // timeline. SENSOR_LANDSCAPE still lets the user flip between
    // landscape-left/right, matching KineMaster's behavior; only portrait
    // is locked out while this screen is open.
    LockScreenOrientation()

    var showExportSheet by remember { mutableStateOf(false) }
    var activeTool by remember { mutableStateOf<String?>(null) }

    // Mark the session "clean" on a graceful exit; if the process dies
    // instead, this never runs and Home's crash-recovery banner fires.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) viewModel.markSessionClean()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    BackHandler {
        viewModel.markSessionClean()
        onBack()
    }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        // Grant persistent read access so the URI is still valid after the app restarts —
        // required since we reference media by URI rather than copying it (§22).
        context.contentResolver.takePersistableUriPermission(
            uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        // MediaMetadataRetriever.close() was only added in API 29; minSdk here is 26,
        // so release() is called manually in a try/finally instead of `use {}`.
        val retriever = MediaMetadataRetriever()
        val durationUs: Long = try {
            retriever.setDataSource(context, uri)
            val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            ms * 1000
        } finally {
            retriever.release()
        }
        viewModel.addVideoClip(uri.toString(), durationUs)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    val name = (uiState as? EditorUiState.Ready)?.project?.name ?: "Loading…"
                    Text(name, maxLines = 1)
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.markSessionClean(); onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { showExportSheet = true }) { Text("Export") }
                }
            )
        }
    ) { padding ->
        when (val state = uiState) {
            is EditorUiState.Loading -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is EditorUiState.Ready -> {
                Column(modifier = Modifier.fillMaxSize().padding(padding)) {

                    // Preview + tool rail side by side — this is the landscape layout
                    // (see LockScreenOrientation above): KineMaster puts its tool panel
                    // on the right edge next to the preview rather than in a bottom bar,
                    // since a bottom bar wastes width once the screen is locked wide.
                    Row(modifier = Modifier.fillMaxWidth().weight(1f)) {

                        // Preview canvas. Real playback here is the GL compositor described in
                        // §16/§20 of the spec, fed by MediaCodec-decoded frames — the same
                        // pipeline export will reuse, so preview and export can never diverge.
                        // That compositor is the next major build item after this scaffold.
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.inverseSurface,
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .aspectRatio(state.project.resolutionWidth.toFloat() / state.project.resolutionHeight)
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                    Text(
                                        "Preview\n(GL compositor not yet wired up)",
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.inverseOnSurface,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        VerticalDivider()

                        ToolRail(
                            onToolSelected = { tool ->
                                if (tool == "Add media") pickMedia.launch("video/*") else activeTool = tool
                            }
                        )
                    }

                    HorizontalDivider()

                    TimelineView(
                        tracks = state.project.tracks,
                        onClipTap = { _, _ -> /* selection handling: next build pass */ },
                        modifier = Modifier.fillMaxWidth().height(140.dp)
                    )
                }
            }
        }
    }

    if (showExportSheet) {
        ExportSheet(onDismiss = { showExportSheet = false })
    }
    activeTool?.let { tool ->
        ToolStubSheet(toolName = tool, onDismiss = { activeTool = null })
    }
}

@Composable
private fun ToolRail(onToolSelected: (String) -> Unit) {
    Column(
        modifier = Modifier
            .width(88.dp)
            .fillMaxHeight()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        tools.forEach { tool ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { onToolSelected(tool.label) }
            ) {
                Icon(tool.icon, contentDescription = tool.label)
                Spacer(Modifier.height(4.dp))
                Text(tool.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ToolStubSheet(toolName: String, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(toolName, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "This tool's controls are the next build pass — the data model " +
                    "(Clip.transform, Clip.effects, Clip.keyframes, TextContent) " +
                    "already has the fields this panel will edit.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExportSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text("Export", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "The MediaCodec hardware-encode pipeline (§18 of the spec) isn't " +
                    "wired up in this scaffold yet. When implemented, this sheet will:\n" +
                    "\n" +
                    "1. Show resolution / frame-rate / format options.\n" +
                    "2. Compute a real free-space check via StatFs and show an " +
                    "estimated output size before the user taps Export.\n" +
                    "3. Stream-encode directly to the final file via MediaMuxer + " +
                    "MediaCodec (no full-resolution temp copy).\n" +
                    "4. Run as a WorkManager job with a progress notification, so " +
                    "it survives the user leaving the app.\n" +
                    "\n" +
                    "No watermark logic exists anywhere in this pipeline, by design.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
