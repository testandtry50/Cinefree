package com.cinefree.app.ui.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.cinefree.app.data.ProjectRepository
import com.cinefree.app.model.Clip
import com.cinefree.app.model.Project
import com.cinefree.app.model.Track
import com.cinefree.app.model.TrackType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface EditorUiState {
    data object Loading : EditorUiState
    data class Ready(val project: Project) : EditorUiState
}

/**
 * Owns the in-memory Project tree for the open edit and persists it after
 * every discrete edit action (autosave — §22). The same `project` value is
 * what a future GL compositor renders for preview, and what the export
 * pipeline walks to produce the final file, so preview and export can never
 * drift apart.
 */
class EditorViewModel(
    private val projectId: String,
    private val repository: ProjectRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<EditorUiState>(EditorUiState.Loading)
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val project = repository.load(projectId) ?: Project(id = projectId, name = "Untitled project")
            _uiState.value = EditorUiState.Ready(project)
        }
    }

    private fun mutate(block: (Project) -> Project) {
        val current = (_uiState.value as? EditorUiState.Ready)?.project ?: return
        val updated = block(current).also { it.modifiedAtEpochMs = System.currentTimeMillis() }
        _uiState.value = EditorUiState.Ready(updated)
        autosave(updated)
    }

    /** Adds an imported media clip to the first video track (creating one if needed). */
    fun addVideoClip(sourceUri: String, durationUs: Long) = mutate { project ->
        val videoTrack = project.tracks.firstOrNull { it.type == TrackType.VIDEO }
            ?: Track(type = TrackType.VIDEO).also { project.tracks.add(0, it) }

        val trackEnd = videoTrack.clips.maxOfOrNull { it.endInTrackUs } ?: 0L
        videoTrack.clips.add(
            Clip(
                sourceUri = sourceUri,
                trimStartUs = 0,
                trimEndUs = durationUs,
                startInTrackUs = trackEnd,
                endInTrackUs = trackEnd + durationUs
            )
        )
        project
    }

    fun removeClip(trackId: String, clipId: String) = mutate { project ->
        project.tracks.firstOrNull { it.id == trackId }?.clips?.removeAll { it.id == clipId }
        project
    }

    fun renameProject(newName: String) = mutate { project ->
        project.name = newName
        project
    }

    /** Called from the editor screen's onPause / onBack — the "graceful exit" half of crash recovery. */
    fun markSessionClean() {
        viewModelScope.launch { repository.markClean(projectId) }
    }

    private fun autosave(project: Project) {
        viewModelScope.launch { repository.save(project, markPossiblyDirty = true) }
    }
}

fun editorViewModelFactory(projectId: String, repository: ProjectRepository) = object : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T =
        EditorViewModel(projectId, repository) as T
}
