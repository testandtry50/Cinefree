package com.cinefree.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// A dark-first palette: an editor's preview canvas needs to be the brightest
// thing on screen, so chrome stays neutral and low-contrast around it.
private val Accent = Color(0xFF5B8DEF)
private val SurfaceDark = Color(0xFF121212)
private val SurfaceLight = Color(0xFFFAFAFA)

private val DarkColors = darkColorScheme(
    primary = Accent,
    background = SurfaceDark,
    surface = SurfaceDark,
)

private val LightColors = lightColorScheme(
    primary = Accent,
    background = SurfaceLight,
    surface = SurfaceLight,
)

@Composable
fun CineFreeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
