package com.cinefree.app.model

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * The in-memory / on-disk representation of a single edit.
 *
 * Design notes:
 *  - Media is referenced by URI, never copied into the project, so project
 *    files stay small (see §22 of the product spec: "Data/project architecture").
 *  - This tree is what both the live GL preview compositor and the export
 *    encoder walk, so preview and export are guaranteed to match (WYSIWYG).
 *  - `schemaVersion` exists so future app versions can migrate old projects
 *    without breaking them — a direct fix for the "freemium ratchet" /
 *    trust-erosion pattern documented in the competitor research.
 */
@Serializable
data class Project(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var aspectRatio: AspectRatio = AspectRatio.RATIO_9_16,
    var resolutionWidth: Int = 1080,
    var resolutionHeight: Int = 1920,
    var frameRate: Int = 30,
    var tracks: MutableList<Track> = mutableListOf(),
    var createdAtEpochMs: Long = System.currentTimeMillis(),
    var modifiedAtEpochMs: Long = System.currentTimeMillis(),
    val schemaVersion: Int = 1
)

@Serializable
enum class AspectRatio(val label: String, val widthRatio: Int, val heightRatio: Int) {
    RATIO_9_16("9:16", 9, 16),
    RATIO_1_1("1:1", 1, 1),
    RATIO_16_9("16:9", 16, 9),
    CUSTOM("Custom", 0, 0)
}

@Serializable
enum class TrackType { VIDEO, AUDIO, TEXT, STICKER, EFFECT }

@Serializable
data class Track(
    val id: String = UUID.randomUUID().toString(),
    val type: TrackType,
    var clips: MutableList<Clip> = mutableListOf(),
    var isMuted: Boolean = false,
    var isHidden: Boolean = false
)

/**
 * A single piece of media (or a text/sticker element) placed on a track.
 *
 * `sourceUri` is null for pure generated layers (text/shapes) that have no
 * backing media file. `startInTrackUs` / `endInTrackUs` are the clip's
 * position on the shared project timeline, in microseconds — matching
 * MediaCodec's native presentation-time units so no unit conversion is
 * needed at encode time.
 */
@Serializable
data class Clip(
    val id: String = UUID.randomUUID().toString(),
    val sourceUri: String? = null,
    var trimStartUs: Long = 0,
    var trimEndUs: Long = 0,
    var startInTrackUs: Long = 0,
    var endInTrackUs: Long = 0,
    var speed: Float = 1.0f,
    var volume: Float = 1.0f,
    var opacity: Float = 1.0f,
    var transform: Transform = Transform(),
    var effects: MutableList<EffectRef> = mutableListOf(),
    var keyframes: MutableList<KeyframeTrack> = mutableListOf(),
    var text: TextContent? = null
)

@Serializable
data class Transform(
    var x: Float = 0f,
    var y: Float = 0f,
    var scale: Float = 1f,
    var rotationDegrees: Float = 0f
)

@Serializable
data class TextContent(
    var value: String,
    var fontFamily: String = "default",
    var colorArgb: Long = 0xFFFFFFFF,
    var sizeSp: Float = 32f
)

/** A reference to a shader-based effect and its parameters (see §16 of the spec). */
@Serializable
data class EffectRef(
    val effectId: String,
    val params: MutableMap<String, Float> = mutableMapOf()
)

/** One animatable property (e.g. "transform.x", "opacity") and its keyframes. */
@Serializable
data class KeyframeTrack(
    val propertyPath: String,
    val points: MutableList<KeyframePoint> = mutableListOf()
)

@Serializable
data class KeyframePoint(
    val timeUs: Long,
    val value: Float,
    val interpolation: Interpolation = Interpolation.EASE_IN_OUT
)

@Serializable
enum class Interpolation { LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, BEZIER }
