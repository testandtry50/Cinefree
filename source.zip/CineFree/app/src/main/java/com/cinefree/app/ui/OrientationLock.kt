package com.cinefree.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext

/** Compose gives us a wrapped Context; unwrap it to find the real hosting Activity. */
tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * Locks screen orientation for as long as the calling composable is in the
 * composition, then restores the given [restoreTo] orientation on exit.
 *
 * Used to mirror the standard mobile-editor pattern (KineMaster, CapCut, VN,
 * etc. all do this): the project browser stays portrait, but the editing
 * screen force-rotates to landscape — more horizontal room for the preview
 * and timeline — and is locked there so an accidental portrait rotation
 * mid-edit doesn't reflow the whole UI.
 *
 * [orientation] defaults to SENSOR_LANDSCAPE rather than plain LANDSCAPE so
 * the user can still flip the phone to the opposite landscape orientation
 * (matching KineMaster's behavior) — portrait is what's locked out, not
 * device rotation in general.
 */
@Composable
fun LockScreenOrientation(
    orientation: Int = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE,
    restoreTo: Int = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
) {
    val context = LocalContext.current
    DisposableEffect(orientation) {
        val activity = context.findActivity()
        val original = activity?.requestedOrientation
        activity?.requestedOrientation = orientation
        onDispose {
            activity?.requestedOrientation = original ?: restoreTo
        }
    }
}
