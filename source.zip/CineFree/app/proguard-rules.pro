# Add project-specific ProGuard rules here.
# Room and kotlinx.serialization generate their own consumer rules; nothing
# app-specific is required yet at this stage of the project.
