# CineFree — Phase 1 MVP scaffold

This is a real, open-able Android Studio project implementing the first slice
of Phase 1 from the Master Build Prompt in `free-no-ai-video-editor-spec.md`.
It was written in a sandbox with no Android SDK and no network access, so
**it has not been compiled here** — open it in Android Studio (Koala/2024.1+)
and let Gradle sync to catch anything that needs a small fix, but the code
is written to compile cleanly against the versions pinned below.

## What's implemented

- Full Gradle project structure (Kotlin + Jetpack Compose + Material 3).
- **Data model** (`model/Project.kt`): Project → Track → Clip, with
  transform/opacity/effects/keyframes fields already in place so later
  phases (keyframing, chroma key, masking) extend this model rather than
  redesigning it.
- **Local-only persistence** (`data/`): Room database storing serialized
  project JSON. No network code exists anywhere in this module.
- **Autosave + crash recovery** (`EditorViewModel.mutate()` /
  `ProjectRepository.save()` / the `hasUnrecoveredCrash` flag + Home
  screen's recovery banner): every discrete edit persists immediately;
  a clean exit clears the crash flag; an unclean shutdown leaves it set so
  Home can offer "Recover."
- **Home screen**: project grid, new-project dialog (name + aspect ratio),
  crash-recovery banner.
- **Editor screen shell**: preview canvas placeholder (correctly sized to
  the project's aspect ratio), a scrollable multi-track timeline view,
  bottom toolbar (Add media / Trim / Text / Audio / Effects), and an
  Export sheet.
- **Real media import**: picking a video via the system picker, reading its
  duration with `MediaMetadataRetriever`, and appending it as a `Clip` on
  a new video track — persisted through the same autosave path.
- Manifest requests no `INTERNET` permission at all in this phase — there
  is nothing in the app that talks to a server.

## What's intentionally stubbed (and why)

- **The GL preview compositor and MediaCodec export pipeline are not
  implemented yet.** These are the two biggest, highest-risk pieces of
  Phase 1 (spec items 4 and 11) and deserve their own focused pass rather
  than being rushed into this scaffolding commit. The `Clip`/`Track` model
  and the timeline UI are already shaped around what that compositor will
  need to read.
- Trim/Text/Audio/Effects toolbar buttons open a bottom sheet that
  explains what will live there — this keeps the navigation flow and
  screen composition real and testable without faking functionality that
  isn't built yet.
- Launcher icon is a placeholder vector glyph, not real app art.

## Next implementation steps, in order

1. **GL compositor** (`OpenGL ES` surface + shader pipeline) that decodes
   frames via `MediaCodec`/`MediaExtractor` and renders the current
   playhead position for the preview canvas — this unblocks WYSIWYG
   playback and is the shared foundation export will reuse.
2. **Trim tool**: drag handles on the selected clip in `TimelineView`,
   writing to `Clip.trimStartUs` / `trimEndUs`.
3. **Export pipeline**: `MediaMuxer` + `MediaCodec` streamed encode, the
   `StatFs`-based free-space check, and a `WorkManager` job — see the
   detailed plan already written into `ExportSheet` in `EditorScreen.kt`.
4. Continue down Phase 1 → Phase 2 → Phase 3 as ordered in the Master
   Build Prompt.

## Build

```
Android Studio Koala (2024.1) or newer
JDK 17
compileSdk 35 / minSdk 26 / targetSdk 35
```

Open the `CineFree/` folder in Android Studio and let Gradle sync — it will
fetch AndroidX Compose, Room, WorkManager, Media3, and kotlinx-serialization
from Google/Maven Central. No other setup is required; there is no API key,
no backend, and no account system to configure.
