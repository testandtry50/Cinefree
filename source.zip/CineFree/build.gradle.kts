// Top-level build file. No AI/ML dependencies, no analytics/ad SDKs by design.
plugins {
    id("com.android.application") version "8.6.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    // Kotlin 2.0+ moved the Compose compiler out of the Android Gradle plugin
    // and into its own Gradle plugin — this is what "What went wrong" flagged.
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "2.0.20" apply false
    id("com.google.devtools.ksp") version "2.0.20-1.0.25" apply false
}
